<template>
  <div>학생 석차조회</div>
</template>

<script></script>

<style></style>
