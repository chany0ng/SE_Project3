<template>
  <div>학생 마이페이지</div>
</template>

<script></script>

<style></style>
