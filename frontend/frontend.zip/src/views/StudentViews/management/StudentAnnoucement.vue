<template>
  <div>학생 공지사항</div>
</template>

<script></script>

<style></style>
