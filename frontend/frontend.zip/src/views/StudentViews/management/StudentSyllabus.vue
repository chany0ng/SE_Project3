<template>
  <div>학생 강의계획서 조회</div>
</template>

<script></script>

<style></style>
