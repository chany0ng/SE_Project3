<template>
  <div>학생 강의 묻고 답하기</div>
</template>

<script></script>

<style></style>
