<template>
  <div>학생 수강신청</div>
</template>

<script></script>

<style></style>
