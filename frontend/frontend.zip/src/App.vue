<template>
  <router-view />
</template>

<style src="../src/assets/style.css"></style>
